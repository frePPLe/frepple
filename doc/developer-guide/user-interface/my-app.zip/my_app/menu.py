"""
This file is used to add customized entries to the menu.
"""

# Use the function "_" for all strings that need translation.
from django.utils.translation import ugettext as _

# This is the menu instance used for all frePPLe screens
from freppledb.menu import menu

# Add a new group and a new item
menu.addGroup("mylinks", label=_("My links"), index=1)
menu.addItem("mylinks", "google", url="http://google.com", window=True, label=_('link to my company'), prefix=False, index=300)
