"""
This file defines an editing form for your models.
"""

# Import your models
from my_app.models import My_Model

# FrePPLe defines 2 admin sites: one for input data, and another for admin data
from freppledb.admin import data_site

# The MultiDBModelAdmin overrides the default one from the Django framework.
# The override is required to be able to use your models correctly in whatif scenarios.
from freppledb.common import MultiDBModelAdmin

class My_Model_Admin(MultiDBModelAdmin):
  model = My_Model
  save_on_top = True
data_site.register(My_Model,My_Model_Admin)
