# Metadata as a frepple app
frepple_app = {
    "summary": "My app",
    "description": """
        <p>Example frepple extension app.</p>
        """,
    "documentation_url": "https://frepple.com/docs/current/developer-guide/creating-an-extension-app.html",
}
